#pragma once
#include <fstream> 
#include <algorithm>
#include "stdafx.h"

#include "DXSample.h"
#include "RaytracingSceneDefines.h"
#include "DirectXRaytracingHelper.h"
//using namespace std;
using namespace DX;

inline void IncludeAABB(D3D12_RAYTRACING_AABB& aabb, const XMFLOAT3& point, const float radius) {
    aabb.MinX = std::min(aabb.MinX, point.x - radius);
    aabb.MaxX = std::max(aabb.MaxX, point.x + radius);
    aabb.MinY = std::min(aabb.MinY, point.y - radius);
    aabb.MaxY = std::max(aabb.MaxY, point.y + radius);
    aabb.MinZ = std::min(aabb.MinZ, point.z - radius);
    aabb.MaxZ = std::max(aabb.MaxZ, point.z + radius);
}

struct Hair {
    struct FileHeader
    {
        // Bytes 0 - 3  Must be "HAIR" in ascii code(48 41 49 52)
        char magic[4];
        // Bytes 4 - 7  Number of hair strands as unsigned int
        uint32_t numStrands;
        // Bytes 8 - 11  Total number of points of all strands as unsigned int
        uint32_t numPoints;
        // Bytes 12 - 15  Bit array of data in the file
        // Bit - 5 to Bit - 31 are reserved for future extension(must be 0).
        uint32_t flags;
        // Bytes 16 - 19  Default number of segments of hair strands as unsigned int
        // If the file does not have a segments array, this default value is used.
        uint32_t defaultNumSegments;
        // Bytes 20 - 23  Default thickness hair strands as float
        // If the file does not have a thickness array, this default value is used.
        float defaultThickness;
        // Bytes 24 - 27  Default transparency hair strands as float
        // If the file does not have a transparency array, this default value is used.
        float defaultAlpha;
        // Bytes 28 - 39  Default color hair strands as float array of size 3
        // If the file does not have a color array, this default value is used.
        XMFLOAT3 defaultColor;
        // Bytes 40 - 127  File information as char array of size 88 in ascii
        char fileInfo[88];
    };

    enum CurveMode {
        LINEAR_BSPLINE = 0,
        QUADRATIC_BSPLINE,
        CUBIC_BSPLINE,
        Count
    };

    FileHeader          m_header;
    std::vector<int>    m_strands;
    std::vector<XMFLOAT3> m_points;
    std::vector<XMFLOAT4> m_vertexData;
    std::vector<float>  m_thickness;

    std::vector<unsigned int> m_aabbMapping;

    CurveMode m_splineMode = CUBIC_BSPLINE;

    std::vector<D3D12_RAYTRACING_AABB> m_aabbs;


    Hair(const std::string& HairFilePath) {
        std::ifstream input(HairFilePath.c_str(), std::ios::binary);

        input.read(reinterpret_cast<char*>(&m_header), sizeof(FileHeader));
        m_header.fileInfo[87] = 0;

        // Segments array(unsigned short)
        // The segements array contains the number of linear segments per strand;
        // thus there are segments + 1 control-points/vertices per strand.
        auto strandSegments = std::vector<unsigned short>(numberOfStrands());
        if (hasSegments())
        {
            input.read(reinterpret_cast<char*>(strandSegments.data()), numberOfStrands() * sizeof(unsigned short));
        }
        else
        {
            std::fill(strandSegments.begin(), strandSegments.end(), defaultNumberOfSegments());
        }

        // Compute strands vector<unsigned int>. Each element is the index to the
        // first point of the first segment of the strand. The last entry is the
        // index "one beyond the last vertex".
        m_strands = std::vector<int>(strandSegments.size() + 1);
        auto strand = m_strands.begin();
        *strand++ = 0;
        for (auto segments : strandSegments)
        {
            *strand = *(strand - 1) + 1 + segments;
            strand++;
        }

        // Points array(float)
        m_points = std::vector<XMFLOAT3>(numberOfPoints());
        input.read(reinterpret_cast<char*>(m_points.data()), numberOfPoints() * sizeof(XMFLOAT3));

        // Thickness array(float)
        m_thickness = std::vector<float>(numberOfPoints());
        if (hasThickness())
        {
            input.read(reinterpret_cast<char*>(m_thickness.data()), numberOfPoints() * sizeof(float));
        }
        else
        {
            std::fill(m_thickness.begin(), m_thickness.end(), defaultThickness());
        }

        m_vertexData = std::vector<XMFLOAT4>(numberOfPoints());
        for (size_t i = 0; i < numberOfPoints(); i++) {
            m_vertexData[i] = XMFLOAT4(m_points[i].x, m_points[i].y, m_points[i].z, m_thickness[i]);
        }


        m_aabbs.resize(50000000);// reserve 50000000 segments
        m_aabbMapping.resize(50000000);
        unsigned int AABBIndex = 0;
        // ÿ��segment��Ҫһ��aabb


        for (size_t index = 0; index < numberOfStrands(); index++) {
            auto startIndex = m_strands[index];
            auto endIndex = m_strands[index + 1] - curveDegree();

            for (int i = startIndex; i < endIndex; ++i) // ��ÿ��segment
            {
                m_aabbs[AABBIndex] = D3D12_RAYTRACING_AABB{
                    0xFFFFFF,
                    0xFFFFFF,
                    0xFFFFFF,
                    -0xFFFFFF,
                    -0xFFFFFF,
                    -0xFFFFFF
                };
                for (int j = 0; j <= curveDegree(); j++) {
                    auto vertexIndex = i + j;
                    IncludeAABB(m_aabbs[AABBIndex], m_points[vertexIndex], m_thickness[vertexIndex]);
                }
                m_aabbMapping[AABBIndex] = i;
                AABBIndex += 1;
            }

        }
        m_aabbs.resize(AABBIndex);
        m_aabbMapping.resize(AABBIndex);

        
    }

    const std::vector<unsigned int> GetStartPointIndexMapping() {// ÿ��aabb�ĵ�һ�����������

    }
    unsigned int GetStartPointIndexMappingNums() {
        return GetAABBNums();
    }

    const std::vector<XMFLOAT4> GetPoints() {
        return m_vertexData;
    }

    unsigned int GetPointNums() {
        return m_vertexData.size();
    }
    unsigned int GetAABBNums() {
        return m_aabbs.size();
    }
    const std::vector<D3D12_RAYTRACING_AABB>& GetAABBs() {
        return m_aabbs;
    }

    uint32_t numberOfStrands() const
    {
        return m_header.numStrands;
    }

    uint32_t numberOfPoints() const
    {
        return m_header.numPoints;
    }

    uint32_t defaultNumberOfSegments() const
    {
        return m_header.defaultNumSegments;
    }

    float defaultThickness() const
    {
        return m_header.defaultThickness;
    }
    float defaultAlpha() const
    {
        return m_header.defaultAlpha;
    }

    XMFLOAT3 defaultColor() const
    {
        return XMFLOAT3(m_header.defaultColor.x, m_header.defaultColor.y, m_header.defaultColor.z);
    }

    std::string fileInfo() const
    {
        return std::string(m_header.fileInfo);
    }

    bool hasSegments() const
    {
        return (m_header.flags & (0x1 << 0)) > 0;
    }

    bool hasPoints() const
    {
        return (m_header.flags & (0x1 << 1)) > 0;
    }

    bool hasThickness() const
    {
        return (m_header.flags & (0x1 << 2)) > 0;
    }

    bool hasAlpha() const
    {
        return (m_header.flags & (0x1 << 3)) > 0;
    }

    bool hasColor() const
    {
        return (m_header.flags & (0x1 << 4)) > 0;
    }

    std::vector<XMFLOAT3> points() const
    {
        return m_points;
    }

    std::vector<float> widths() const
    {
        return m_thickness;
    }

    int numberOfSegments() const
    {
        return numberOfPoints() - numberOfStrands() * curveDegree();
    }

    // Compute a list of all segment indices making up the curves array.
    //
    // The structure of the list is as follows:
    // * For each strand all segments are listed in order from root to tip.
    // * Segment indices are identical to the index of the first control-point
    //   of a segment.
    // * The number of segments per strand is dependent on the curve degree; e.g.
    //   a cubic segment requires four control points, thus a cubic strand with n
    //   control points will have (n - 3) segments.
    //
    std::vector<int> segments() const
    {
        std::vector<int> segments;
        // loop to one before end, as last strand value is the "past last valid vertex"
        // index
        for (auto strand = m_strands.begin(); strand != m_strands.end() - 1; ++strand)
        {
            const int start = *(strand);                      // first vertex in first segment
            const int end = *(strand + 1) - curveDegree();  // second vertex of last segment
            for (int i = start; i < end; ++i)
            {
                segments.push_back(i);
            }
        }

        return segments;
    }

    std::vector<XMFLOAT2> strandU() const
    {
        std::vector<XMFLOAT2> strand_u;
        for (auto strand = m_strands.begin(); strand != m_strands.end() - 1; ++strand)
        {
            const int   start = *(strand);
            const int   end = *(strand + 1) - curveDegree();
            const int   segments = end - start;  // number of strand's segments
            const float scale = 1.0f / segments;
            for (int i = 0; i < segments; ++i)
            {
                strand_u.push_back(XMFLOAT2(i * scale, scale));
            }
        }

        return strand_u;
    }

    std::vector<int> strandIndices() const
    {
        std::vector<int> strandIndices;
        int              strandIndex = 0;
        for (auto strand = m_strands.begin(); strand != m_strands.end() - 1; ++strand)
        {
            const int start = *(strand);
            const int end = *(strand + 1) - curveDegree();
            for (auto segment = start; segment != end; ++segment)
            {
                strandIndices.push_back(strandIndex);
            }
            ++strandIndex;
        }

        return strandIndices;
    }

    std::vector<XMUINT2> strandInfo() const
    {
        std::vector<XMUINT2> strandInfo;
        unsigned int       firstPrimitiveIndex = 0;
        for (auto strand = m_strands.begin(); strand != m_strands.end() - 1; ++strand)
        {
            XMUINT2 info;
            info.x = firstPrimitiveIndex;                        // strand's start index
            info.y = *(strand + 1) - *(strand)-curveDegree();  // number of segments in strand
            firstPrimitiveIndex += info.y;                       // increment with number of primitives/segments in strand
            strandInfo.push_back(info);
        }
        return strandInfo;
    }


    unsigned int curveDegree() const
    {
        switch (m_splineMode) {
        case LINEAR_BSPLINE:
            return 1;
        case QUADRATIC_BSPLINE:
            return 2;
        case CUBIC_BSPLINE:
            return 3;
        default:
            return 0;
        }
    }
};
